/*
 * LCD_config.h
 *
 * Created: 2/23/2018 7:55:06 PM
 *  Author: Mohamed Zaghlol
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_
#define four_bits_mode
#endif /* LCD_CONFIG_H_ */